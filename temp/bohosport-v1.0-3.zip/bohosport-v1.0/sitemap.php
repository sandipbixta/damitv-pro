<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/loader.php';

$categories_data = fetch_api('/sports');
$categories = $categories_data['data'] ?? [];

header('Content-Type: application/xml; charset=utf-8');

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

echo "  <sitemap>\n";
echo "    <loc>" . rtrim(BASE_URL, '/') . "/sitemap-pages.xml</loc>\n";
echo "    <lastmod>" . date('Y-m-d') . "</lastmod>\n";
echo "  </sitemap>\n";

if (!empty($categories)) {
    foreach ($categories as $category) {
        $cat_slug = htmlspecialchars($category['id']);
        echo "  <sitemap>\n";
        echo "    <loc>" . rtrim(BASE_URL, '/') . "/sitemap-" . $cat_slug . ".xml</loc>\n";
        echo "    <lastmod>" . date('Y-m-d') . "</lastmod>\n";
        echo "  </sitemap>\n";
    }
}

echo '</sitemapindex>';
?>