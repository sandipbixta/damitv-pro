<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Server Readiness Check</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f7f6;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            overflow: hidden;
        }
        h1 {
            text-align: center;
            padding: 20px 0;
            margin: 0;
            background-color: #2c3e50;
            color: #ecf0f1;
            font-weight: 600;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background-color: #f9f9f9;
            font-weight: 600;
        }
        tr:last-child td {
            border-bottom: none;
        }
        .status {
            font-weight: 700;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 0.9em;
            text-align: center;
        }
        .ok {
            background-color: #d4edda;
            color: #155724;
        }
        .fail {
            background-color: #f8d7da;
            color: #721c24;
        }
        .info {
            background-color: #e2e3e5;
            color: #383d41;
        }
        .summary {
            padding: 20px;
            font-size: 1.2em;
            font-weight: 600;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Server Readiness Check</h1>
        <table>
            <thead>
                <tr>
                    <th>Check</th>
                    <th>Status</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $all_ready = true; 

                $php_version = PHP_VERSION;
                $requirement_met = (version_compare($php_version, '8.1.0', '>=') && version_compare($php_version, '8.3.0', '<'));

                if ($requirement_met) {
                    echo '<tr>
                            <td>PHP Version</td>
                            <td><span class="status ok">REQUIRED PASS</span></td>
                            <td>Your version: <strong>' . $php_version . '</strong> (Meets requirement 8.1.x or 8.2.x)</td>
                          </tr>';
                } else {
                    $all_ready = false; 
                    echo '<tr>
                            <td>PHP Version</td>
                            <td><span class="status fail">REQUIRED FAIL</span></td>
                            <td>Your version: <strong>' . $php_version . '</strong>. This script REQUIRES PHP 8.1 or 8.2. Please change your PHP version.</td>
                          </tr>';
                }

                if (extension_loaded('ioncube loader') || extension_loaded('IonCube Loader')) {
                    $ion_ver = function_exists('ioncube_loader_version') ? ioncube_loader_version() : 'Unknown';
                    echo '<tr>
                            <td>Extension: IonCube Loader</td>
                            <td><span class="status ok">REQUIRED PASS</span></td>
                            <td>IonCube Loader is installed. Version: <strong>' . $ion_ver . '</strong></td>
                          </tr>';
                } else {
                    $all_ready = false;
                    echo '<tr>
                            <td>Extension: IonCube Loader</td>
                            <td><span class="status fail">REQUIRED FAIL</span></td>
                            <td><strong>IonCube Loader NOT found.</strong> Encoded scripts will not run.</td>
                          </tr>';
                }

                if (extension_loaded('curl')) {
                    echo '<tr>
                            <td>Extension: cURL</td>
                            <td><span class="status ok">REQUIRED PASS</span></td>
                            <td>cURL extension is active.</td>
                          </tr>';
                } else {
                    $all_ready = false;
                    echo '<tr>
                            <td>Extension: cURL</td>
                            <td><span class="status fail">REQUIRED FAIL</span></td>
                            <td><strong>cURL extension NOT found.</strong> Script cannot fetch streams.</td>
                          </tr>';
                }

                if (extension_loaded('openssl')) {
                    echo '<tr>
                            <td>Extension: OpenSSL</td>
                            <td><span class="status ok">REQUIRED PASS</span></td>
                            <td>OpenSSL extension is active (Required for HTTPS).</td>
                          </tr>';
                } else {
                    $all_ready = false;
                    echo '<tr>
                            <td>Extension: OpenSSL</td>
                            <td><span class="status fail">REQUIRED FAIL</span></td>
                            <td><strong>OpenSSL extension NOT found.</strong> Cannot access HTTPS streams.</td>
                          </tr>';
                }

                if (extension_loaded('json')) {
                    echo '<tr>
                            <td>Extension: JSON</td>
                            <td><span class="status ok">REQUIRED PASS</span></td>
                            <td>JSON extension is active.</td>
                          </tr>';
                } else {
                    $all_ready = false;
                    echo '<tr>
                            <td>Extension: JSON</td>
                            <td><span class="status fail">REQUIRED FAIL</span></td>
                            <td><strong>JSON extension NOT found.</strong> Cannot process API data.</td>
                          </tr>';
                }

                if (ini_get('allow_url_fopen')) {
                    echo '<tr>
                            <td>Setting: allow_url_fopen</td>
                            <td><span class="status info">INFO</span></td>
                            <td>Status: <strong>On</strong>. (Some scripts may need this).</td>
                          </tr>';
                } else {
                    echo '<tr>
                            <td>Setting: allow_url_fopen</td>
                            <td><span class="status info">INFO</span></td>
                            <td>Status: <strong>Off</strong>. (This is fine if script uses cURL).</td>
                          </tr>';
                }

                $max_exec = ini_get('max_execution_time');
                echo '<tr>
                        <td>Setting: max_execution_time</td>
                        <td><span class="status info">INFO</span></td>
                        <td>Execution time limit: <strong>' . $max_exec . ' seconds</strong> (0 = unlimited).</td>
                      </tr>';

                $mem_limit = ini_get('memory_limit');
                echo '<tr>
                        <td>Setting: memory_limit</td>
                        <td><span class="status info">INFO</span></td>
                        <td>Memory limit: <strong>' . $mem_limit . '</strong>.</td>
                      </tr>';

                ?>
            </tbody>
        </table>
        
        <?php
        if ($all_ready) {
            echo '<div class="summary ok">SERVER IS READY! All required checks (REQUIRED PASS) have passed.</div>';
        } else {
            echo '<div class="summary fail">SERVER NOT READY! One or more required checks (REQUIRED FAIL) have not been met. Please fix them.</div>';
        }
        ?>

    </div>

</body>
</html>