<div id="view-404" class="text-center py-10">
    <h1 class="text-6xl font-bold text-gray-400">404</h1>
    <p class="text-2xl font-semibold text-white mt-4">Page Not Found</p>
    <p class="text-gray-400 mt-2">
        We're sorry, but the page you were looking for doesn't exist.
    </p>
    <a href="/" class="mt-8 inline-block bg-blue-600 text-white px-6 py-3 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
        &larr; Back to Home
    </a>
</div>