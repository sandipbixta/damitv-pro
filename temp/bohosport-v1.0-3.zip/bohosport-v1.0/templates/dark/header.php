<?php
$meta_title = htmlspecialchars($page_title) . ' - ' . SITE_NAME;
$meta_desc = 'Watch live sports streams for free on ' . SITE_NAME . '. Get the best quality, multiple servers, and real-time updates for all major sports events.';
$meta_keywords = 'live sport, streaming, football, basketball, watch online, ' . SITE_NAME;
$meta_url = rtrim(BASE_URL, '/') . $_SERVER['REQUEST_URI'];
$meta_image = rtrim(BASE_URL, '/') . '/assets/images/default-share-image.png';

if (isset($og_image) && $og_image !== PLACEHOLDER_IMG) {
    $meta_image = $og_image;
}

$schemas = [];

if (isset($match) && $match) {
    $cat_name = htmlspecialchars(ucfirst($match['category'] ?? 'live'));
    $match_date = $match['date'] ?? 0;
    $iso_date = format_iso_date($match_date);
    $date_string = format_seo_date($match_date);

    if ($match_date === 0) {
        $title = htmlspecialchars($match['title']);
        $meta_title = "Watch $title - Live $cat_name Channel - " . SITE_NAME;
        $meta_desc = "Watch the $title live stream 24/7 on " . SITE_NAME . ". Best $cat_name channel for free.";
        $meta_keywords = "$title, $cat_name, live channel, live stream, " . SITE_NAME;
        $schemas[] = ["@context" => "https://schema.org", "@type" => "BroadcastService", "name" => $title, "description" => $meta_desc, "provider" => ["@type" => "Organization", "name" => SITE_NAME]];
    } else {
        $home_name = null;
        $away_name = null;
        $home_badge = null;
        $away_badge = null;
        $title = htmlspecialchars($match['title']);
        if (!empty($match['teams']['home']['name'])) {
            $home_name = htmlspecialchars($match['teams']['home']['name']);
            $away_name = htmlspecialchars($match['teams']['away']['name'] ?? 'Opponent');
            $home_badge = $match['teams']['home']['badge'] ?? null;
            $away_badge = $match['teams']['away']['badge'] ?? null;
            $title = "$home_name vs $away_name";
        } else {
            $parts = explode(' vs ', $match['title']);
            if (count($parts) === 2) {
                $home_name = htmlspecialchars(trim($parts[0]));
                $away_name = htmlspecialchars(trim($parts[1]));
                $title = "$home_name vs $away_name";
            }
        }
        $meta_title = "Watch $title $cat_name Live Stream - " . SITE_NAME;
        $meta_desc = "Watch $title live stream $date_string. Get the best quality $cat_name stream for free on " . SITE_NAME . ". Don't miss any action!";
        $meta_keywords = "$title, $cat_name, live stream, watch $title, " . SITE_NAME;
        if ($home_name) $meta_keywords = $home_name . ', ' . $meta_keywords;
        if ($away_name) $meta_keywords = $away_name . ', ' . $meta_keywords;
        $event_schema = [
            "@context" => "https://schema.org", "@type" => "SportsEvent", "name" => $title, "startDate" => $iso_date, "description" => $meta_desc,
            "location" => ["@type" => "VirtualLocation", "url" => $meta_url],
            "offers" => ["@type" => "Offer", "price" => "0", "priceCurrency" => "USD", "availability" => "https://schema.org/InStock", "url" => $meta_url]
        ];
        if ($home_name && $away_name) {
            $event_schema["competitor"] = [
                ["@type" => "SportsTeam", "name" => $home_name, "image" => $home_badge],
                ["@type" => "SportsTeam", "name" => $away_name, "image" => $away_badge]
            ];
        }
        $schemas[] = $event_schema;
    }
} elseif (isset($page) && $page === 'scores') {
    $meta_title = htmlspecialchars($page_title) . ' - ' . SITE_NAME;
    $meta_desc = $seo_p1;
    $meta_keywords = htmlspecialchars($current_league_name) . ', football scores, live scores, football tables, ' . SITE_NAME;
}

$breadcrumb_elements = [];
$breadcrumb_elements[] = [
    "@type" => "ListItem",
    "position" => 1,
    "name" => "Home",
    "item" => rtrim(BASE_URL, '/') . '/'
];

if (isset($current_category) && $page_title !== 'Home' && $page !== 'scores') {
    $cat_slug = $current_category;
    $cat_name_for_crumb = ucfirst($cat_slug);
    foreach ($categories as $cat) {
        if ($cat['id'] === $cat_slug) {
            $cat_name_for_crumb = $cat['name'];
            break;
        }
    }

    $breadcrumb_elements[] = [
        "@type" => "ListItem",
        "position" => 2,
        "name" => $cat_name_for_crumb,
        "item" => rtrim(BASE_URL, '/') . '/' . $cat_slug . '/'
    ];
}

if (isset($match) && $match) {
    $breadcrumb_elements[] = [
        "@type" => "ListItem",
        "position" => 3,
        "name" => $page_title,
        "item" => $meta_url
    ];
}

if ($page === 'scores') {
    $breadcrumb_elements[] = [
        "@type" => "ListItem",
        "position" => 2,
        "name" => "Live Scores",
        "item" => rtrim(BASE_URL, '/') . '/scores/'
    ];
    if ($is_filtered_page) {
        $breadcrumb_elements[] = [
            "@type" => "ListItem",
            "position" => 3,
            "name" => $current_league_name,
            "item" => $meta_url
        ];
    }
}

$schemas[] = [
    "@context" => "https://schema.org",
    "@type" => "BreadcrumbList",
    "itemListElement" => $breadcrumb_elements
];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $meta_title; ?></title>
    <meta name="description" content="<?php echo $meta_desc; ?>">
    <meta name="keywords" content="<?php echo $meta_keywords; ?>">
    <link rel="canonical" href="<?php echo $meta_url; ?>" />
    <link rel="icon" type="image/png" sizes="192x192" href="/assets/images/icon-192x192.png">
    <link rel="apple-touch-icon" href="/assets/images/icon-192x192.png">
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#111827">

    <meta property="og:title" content="<?php echo $meta_title; ?>" />
    <meta property="og:description" content="<?php echo $meta_desc; ?>" />
    <meta property="og:image" content="<?php echo $meta_image; ?>" />
    <meta property="og:url" content="<?php echo $meta_url; ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="<?php echo SITE_NAME; ?>" />

    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="<?php echo $meta_title; ?>" />
    <meta name="twitter:description" content="<?php echo $meta_desc; ?>" />
    <meta name="twitter:image" content="<?php echo $meta_image; ?>" />

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        html,
        body {
            font-family: 'Inter', sans-serif;
            background-color: #1F2937;
            color: #E5E7EB;
            height: 100%;
        }

        .dark-select {
            background-color: #1F2937;
            border-color: #374151;
            color: #E5E7EB;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%239CA3AF' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3E%3C/svg%3E");
            background-position: right 0.5rem center;
            background-repeat: no-repeat;
            background-size: 1.5em 1.5em;
            padding-right: 2.5rem;
        }

        .team-badge {
            width: 2.5rem;
            height: 2.5rem;
            object-fit: contain;
            background-color: #374151;
            border-radius: 9999px;
        }

        .team-badge-sm {
            width: 1.5rem;
            height: 1.5rem;
            object-fit: contain;
            background-color: #374151;
            border-radius: 9999px;
        }

        #player-container .aspect-video {
            position: relative;
            padding-bottom: 56.25%;
            height: 0;
            overflow: hidden;
            background-color: #000;
            border-radius: 0.5rem;
        }

        #player-container iframe {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            border: none;
        }

        .nav-link {
            display: block;
            padding: 0.5rem 0.75rem;
            border-radius: 0.5rem;
            color: #D1D5DB;
            transition: background-color 0.2s, color 0.2s;
        }

        .nav-link:hover {
            color: #FFFFFF;
            background-color: #374151;
        }

        @media (min-width: 768px) {
            .nav-link {
                display: inline-block;
            }
        }

        .tab-link {
            padding: 0.75rem 1.5rem;
            font-size: 0.875rem;
            font-weight: 600;
            line-height: 1.25rem;
            color: #9CA3AF;
            border-bottom: 2px solid transparent;
            cursor: pointer;
            transition: all 0.2s;
        }

        .tab-link:hover {
            color: #E5E7EB;
            border-bottom-color: #374151;
        }

        .tab-link.tab-active {
            color: #3B82F6;
            border-bottom-color: #3B82F6;
        }

        .share-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.65rem;
            border-radius: 0.5rem;
            color: #E5E7EB;
            transition: all 0.2s ease-in-out;
            background-color: #374151;
        }

        .share-button:hover {
            color: #FFFFFF;
            transform: scale(1.1);
        }
    </style>

    <?php
    if (!empty($schemas)) {
        $json_to_print = (count($schemas) === 1) ? $schemas[0] : $schemas;
        echo '<script type="application/ld+json">' . json_encode($json_to_print, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>';
    }
    ?>

</head>

<body class="min-h-screen">

    <header class="bg-gray-900 shadow-lg sticky top-0 z-50">
        <div class="container max-w-6xl mx-auto p-4 flex flex-wrap justify-between items-center gap-4">

            <a href="/" class="text-2xl font-bold text-white cursor-pointer">
                <span class="text-blue-500">Sport</span>LIVE
            </a>

            <button id="menu-toggle" class="md:hidden p-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-700" aria-controls="main-menu" aria-expanded="false">
                <span class="sr-only">Menu</span>
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
                </svg>
            </button>

            <div id="main-menu" class="hidden w-full md:flex md:w-auto md:items-center md:gap-4">

                <nav class="w-full md:w-auto mt-4 md:mt-0">
                    <a href="/" class="nav-link">Home</a>
                    <a href="/scores/" class="nav-link">Scores</a>
                </nav>

                <div class="flex-shrink-0 w-full sm:w-auto max-w-xs mt-4 md:mt-0">
                    <select id="category-select" class="dark-select w-full rounded-lg border border-gray-700 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Sport Categories...</option>
                        <?php if (!empty($categories)) : ?>
                            <?php foreach ($categories as $category) : ?>
                                <option value="<?php echo htmlspecialchars($category['id']); ?>" <?php echo (isset($current_category) && $current_category === $category['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <option value="" disabled>Failed to load</option>
                        <?php endif; ?>
                    </select>
                </div>
            </div>

        </div>
    </header>

    <main class="container max-w-6xl mx-auto p-4 md:p-6">