<?php
$live_count = count($live_matches);
$finished_count = count($finished_matches);
$tables_count = count($tables_data);

$active_tab = 'tables';
if ($finished_count > 0) $active_tab = 'finished';
if ($live_count > 0) $active_tab = 'live';

?>

<div id="view-scores">
    <div class="mb-2 text-sm text-gray-400">
        <nav class="flex" aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2">
                <li class="inline-flex items-center">
                    <a href="/" class="inline-flex items-center hover:text-white">Home</a>
                </li>
                <li class="inline-flex items-center">
                    <a href="/scores/" class="inline-flex items-center hover:text-white">
                        <span class="mx-1">/</span>
                        Live Scores
                    </a>
                </li>
                <?php if ($is_filtered_page) : ?>
                    <li aria-current="page">
                        <div class="flex items-center">
                            <span class="mx-1">/</span>
                            <span class="text-gray-500"><?php echo htmlspecialchars($current_league_name); ?></span>
                        </div>
                    </li>
                <?php endif; ?>
            </ol>
        </nav>
    </div>

    <div class="flex flex-col sm:flex-row justify-between sm:items-center mb-6 gap-2">
        <h1 class="text-2xl sm:text-3xl font-bold text-white">
            <?php echo htmlspecialchars($page_title); ?>
        </h1>

        <?php if ($is_filtered_page && $last_updated_timestamp_ms > 0) : ?>
            <p class="text-xs text-gray-400 flex-shrink-0">
                Last Updated: <span class="local-time-full" data-timestamp="<?php echo $last_updated_timestamp_ms; ?>">...</span>
            </p>
        <?php endif; ?>
    </div>

    <div class="mb-4">
        <label for="league-select" class="block text-sm font-medium text-gray-300 mb-1">Select League:</label>
        <select id="league-select" class="dark-select w-full rounded-lg border border-gray-700 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">

            <option value="">All Leagues</option>

            <?php foreach ($all_leagues as $league) : ?>
                <option value="<?php echo htmlspecialchars($league['id']); ?>" <?php echo $is_filtered_page && $current_league_slug === $league['id'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($league['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <?php if (!$is_filtered_page) : ?>
        <div class="bg-gray-700 p-6 rounded-lg text-center">
            <h3 class="text-lg font-semibold text-white mb-2">Please Select a League</h3>
            <p class="text-gray-300">Choose a league from the dropdown menu above to view live scores, match results, and league tables.</p>
        </div>
    <?php else : ?>
        <div class="mb-4 border-b border-gray-700">
            <nav id="match-tab-nav" class="flex -mb-px" aria-label="Tabs">
                <button class="tab-link <?php echo ($active_tab === 'live') ? 'tab-active' : ''; ?> flex-1 text-center" data-tab="live">
                    Live (<?php echo $live_count; ?>)
                </button>
                <button class="tab-link <?php echo ($active_tab === 'finished') ? 'tab-active' : ''; ?> flex-1 text-center" data-tab="finished">
                    Finished (<?php echo $finished_count; ?>)
                </button>
                <button class="tab-link <?php echo ($active_tab === 'tables') ? 'tab-active' : ''; ?> flex-1 text-center" data-tab="tables">
                    Tables
                </button>
            </nav>
        </div>

        <div id="match-list-panels">

            <div id="tab-panel-live" class="tab-panel space-y-3 <?php echo ($active_tab !== 'live') ? 'hidden' : ''; ?>">
                <?php if ($live_count > 0) : ?>
                    <?php foreach ($live_matches as $match) : ?>
                        <?php
                        $home = $match['homeTeam'];
                        $away = $match['awayTeam'];
                        $score = $match['score']['fullTime'];
                        ?>
                        <div class="block bg-gray-700 p-4 rounded-lg shadow-md">
                            <div class="grid grid-cols-3 items-center text-center">
                                <div class="flex flex-col sm:flex-row items-center justify-end gap-3">
                                    <span class="text-sm sm:text-base font-semibold text-white text-right"><?php echo htmlspecialchars($home['name']); ?></span>
                                    <img src="<?php echo htmlspecialchars($home['crest']); ?>" alt="<?php echo htmlspecialchars($home['shortName']); ?>" class="team-badge" onerror="this.src='<?php echo PLACEHOLDER_IMG; ?>'">
                                </div>
                                <div class="mx-4 text-center">
                                    <p class="text-2xl font-bold text-white"><?php echo (int)($score['home'] ?? 0); ?> - <?php echo (int)($score['away'] ?? 0); ?></p>
                                    <p class="text-sm font-bold text-red-500 animate-pulse">
                                        <?php echo htmlspecialchars($match['minute'] ?? 'LIVE'); ?>'
                                    </p>
                                </div>
                                <div class="flex flex-col-reverse sm:flex-row items-center justify-start gap-3">
                                    <img src="<?php echo htmlspecialchars($away['crest']); ?>" alt="<?php echo htmlspecialchars($away['shortName']); ?>" class="team-badge" onerror="this.src='<?php echo PLACEHOLDER_IMG; ?>'">
                                    <span class="text-sm sm:text-base font-semibold text-white text-left"><?php echo htmlspecialchars($away['name']); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else : ?>
                    <p class="text-gray-400 text-center py-8">No Live matches at this time for this league.</p>
                <?php endif; ?>
            </div>

            <div id="tab-panel-finished" class="tab-panel space-y-3 <?php echo ($active_tab !== 'finished') ? 'hidden' : ''; ?>">
                <?php if ($finished_count > 0) : ?>
                    <?php foreach ($finished_matches as $match) : ?>
                        <?php
                        $home = $match['homeTeam'];
                        $away = $match['awayTeam'];
                        $score = $match['score']['fullTime'];
                        $timestamp_ms = strtotime($match['utcDate']) * 1000;
                        ?>
                        <div class="block bg-gray-700 p-4 rounded-lg shadow-md">
                            <div class="grid grid-cols-3 items-center text-center">
                                <div class="flex flex-col sm:flex-row items-center justify-end gap-3">
                                    <span class="text-sm sm:text-base font-semibold text-white text-right"><?php echo htmlspecialchars($home['name']); ?></span>
                                    <img src="<?php echo htmlspecialchars($home['crest']); ?>" alt="<?php echo htmlspecialchars($home['shortName']); ?>" class="team-badge" onerror="this.src='<?php echo PLACEHOLDER_IMG; ?>'">
                                </div>
                                <div class="mx-4 text-center">
                                    <p class="text-2xl font-bold text-white"><?php echo (int)($score['home'] ?? 0); ?> - <?php echo (int)($score['away'] ?? 0); ?></p>
                                    <div class="local-time-date text-sm text-gray-400" data-timestamp="<?php echo $timestamp_ms; ?>">
                                        Full Time
                                    </div>
                                </div>
                                <div class="flex flex-col-reverse sm:flex-row items-center justify-start gap-3">
                                    <img src="<?php echo htmlspecialchars($away['crest']); ?>" alt="<?php echo htmlspecialchars($away['shortName']); ?>" class="team-badge" onerror="this.src='<?php echo PLACEHOLDER_IMG; ?>'">
                                    <span class="text-sm sm:text-base font-semibold text-white text-left"><?php echo htmlspecialchars($away['name']); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else : ?>
                    <p class="text-gray-400 text-center py-8">No finished matches found for this league.</p>
                <?php endif; ?>
            </div>

            <div id="tab-panel-tables" class="tab-panel <?php echo ($active_tab !== 'tables') ? 'hidden' : ''; ?>">
                <?php if ($tables_count > 0) : ?>
                    <div class="overflow-x-auto bg-gray-700 rounded-lg shadow-md">
                        <table class="w-full min-w-max text-left text-sm text-gray-300">
                            <thead class="text-xs text-gray-400 uppercase bg-gray-800">
                                <tr>
                                    <th scope="col" class="px-2 py-3 text-center">Pos</th>
                                    <th scope="col" class="px-4 py-3">Team</th>
                                    <th scope="col" class="px-2 py-3 text-center" title="Played">Pl</th>
                                    <th scope="col" class="px-2 py-3 text-center" title="Won">W</th>
                                    <th scope="col" class="px-2 py-3 text-center" title="Draw">D</th>
                                    <th scope="col" class="px-2 py-3 text-center" title="Lost">L</th>
                                    <th scope="col" class="px-2 py-3 text-center" title="Goals For">GF</th>
                                    <th scope="col" class="px-2 py-3 text-center" title="Goals Against">GA</th>
                                    <th scope="col" class="px-2 py-3 text-center" title="Goal Difference">GD</th>
                                    <th scope="col" class="px-3 py-3 text-center font-bold">Pts</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($tables_data as $row) : ?>
                                    <tr class="border-b border-gray-800 hover:bg-gray-600">
                                        <td class="px-2 py-3 text-center font-medium <?php echo $row['position'] <= 4 ? 'text-white' : ''; ?>">
                                            <?php echo htmlspecialchars($row['position']); ?>
                                        </td>
                                        <td class="px-4 py-3 font-semibold text-white">
                                            <div class="flex items-center gap-3">
                                                <img src="<?php echo htmlspecialchars($row['team']['crest']); ?>" alt="<?php echo htmlspecialchars($row['team']['name']); ?>" class="team-badge-sm" onerror="this.src='<?php echo PLACEHOLDER_IMG; ?>'">
                                                <span><?php echo htmlspecialchars($row['team']['name']); ?></span>
                                            </div>
                                        </td>
                                        <td class="px-2 py-3 text-center"><?php echo htmlspecialchars($row['playedGames']); ?></td>
                                        <td class="px-2 py-3 text-center"><?php echo htmlspecialchars($row['won']); ?></td>
                                        <td class="px-2 py-3 text-center"><?php echo htmlspecialchars($row['draw']); ?></td>
                                        <td class="px-2 py-3 text-center"><?php echo htmlspecialchars($row['lost']); ?></td>
                                        <td class="px-2 py-3 text-center"><?php echo htmlspecialchars($row['goalsFor']); ?></td>
                                        <td class="px-2 py-3 text-center"><?php echo htmlspecialchars($row['goalsAgainst']); ?></td>
                                        <td class="px-2 py-3 text-center"><?php echo htmlspecialchars($row['goalDifference']); ?></td>
                                        <td class="px-3 py-3 text-center font-bold text-white"><?php echo htmlspecialchars($row['points']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else : ?>
                    <p class="text-gray-400 text-center py-8">No table data available for this league.</p>
                <?php endif; ?>
            </div>

        </div>
    <?php endif; ?>

    <div id="seo-description-block" class="mt-8 pt-6 border-t border-gray-700 text-gray-400 text-sm space-y-3">
        <h2 class="text-xl font-semibold text-white"><?php echo $seo_title; ?> on <?php echo $seo_site_name; ?></h2>
        <p><?php echo $seo_p1; ?></p>
        <p><?php echo $seo_p2; ?></p>
    </div>
</div>