<?php
$matches_data = fetch_api('/matches/' . $current_category);
$matches = $matches_data['data'] ?? [];

$live_matches = [];
$scheduled_matches = [];
$stream_channels = [];
$now = time() * 1000;

if (!empty($matches)) {
    foreach ($matches as $match) {
        
        $matchTime = $match['date'] ?? 0;

        if ($matchTime === 0) {
            $stream_channels[] = $match;
            continue;
        }

        $isLive = ($matchTime <= $now);
        
        if ($isLive) {
            $live_matches[] = $match;
        } else {
            $scheduled_matches[] = $match;
        }
    }

    usort($live_matches, function($a, $b) {
        $popA = $a['popular'] ?? 0; $popB = $b['popular'] ?? 0;
        if ($popA !== $popB) return $popB - $popA;
        return ($b['date'] ?? 0) - ($a['date'] ?? 0);
    });

    usort($scheduled_matches, function($a, $b) {
        $popA = $a['popular'] ?? 0; $popB = $b['popular'] ?? 0;
        if ($popA !== $popB) return $popB - $popA;
        return ($a['date'] ?? 0) - ($b['date'] ?? 0);
    });
    
    usort($stream_channels, function($a, $b) {
        $popA = $a['popular'] ?? 0; $popB = $b['popular'] ?? 0;
        if ($popA !== $popB) return $popB - $popA;
        return strcmp($a['title'], $b['title']);
    });
}

$active_tab = 'schedule';
if (!empty($live_matches)) {
    $active_tab = 'live';
}

$seo_category_name = ($page_title === 'Home') ? 'Sport' : htmlspecialchars($page_title);
$seo_site_name = SITE_NAME;

$seo_live_names = [];
if (!empty($live_matches)) {
    foreach (array_slice($live_matches, 0, 3) as $match) {
        $seo_live_names[] = htmlspecialchars($match['title']);
    }
}

$seo_scheduled_names = [];
if (!empty($scheduled_matches)) {
    foreach (array_slice($scheduled_matches, 0, 3) as $match) {
        $seo_scheduled_names[] = htmlspecialchars($match['title']);
    }
}

$seo_p1 = "Watch live {$seo_category_name} streams for free on {$seo_site_name}. Get real-time updates, high-quality streams, and the best coverage for all {$seo_category_name} events.";

$seo_p2 = "";
if (empty($seo_live_names) && !empty($seo_scheduled_names)) {
    $seo_p2 = "There are no live matches right now, but don't miss upcoming events like " . implode(', ', $seo_scheduled_names) . ".";
} elseif (!empty($seo_live_names) && !empty($seo_scheduled_names)) {
    $seo_p2 = "Currently, you can watch live matches like " . implode(', ', $seo_live_names) . ". Plus, get ready for upcoming games including " . implode(', ', $seo_scheduled_names) . ".";
} elseif (!empty($seo_live_names) && empty($seo_scheduled_names)) {
    $seo_p2 = "Currently, you can watch live matches like " . implode(', ', $seo_live_names) . ". Check back later for more scheduled events.";
} else {
    $seo_p2 = "Check back soon for live streams and schedules for your favorite {$seo_category_name} teams and events.";
}
?>

<div id="view-matches">

    <div class="mb-2 text-sm text-gray-400">
        <nav class="flex" aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2">
                <li class="inline-flex items-center">
                    <a href="/" class="inline-flex items-center hover:text-white">Home</a>
                </li>
                <?php
                if ($page_title !== 'Home'):
                ?>
                <li aria-current="page">
                    <div class="flex items-center">
                        <span class="mx-1">/</span>
                        <span class="text-gray-500 capitalize"><?php echo htmlspecialchars($page_title); ?></span>
                    </div>
                </li>
                <?php endif; ?>
            </ol>
        </nav>
    </div>

    <h1 class="text-2xl sm:text-3xl font-bold text-white mb-4">
        <?php 
            $h1_title = ($page_title === 'Home') ? 'Sport' : htmlspecialchars($page_title);
            echo $h1_title; 
        ?> Streams
    </h1>

    <div class="mb-4">
        <input type="search" id="match-search-input"
            class="dark-select w-full rounded-lg border border-gray-700 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Search for teams or channels...">
    </div>

    <div class="mb-4 border-b border-gray-700">
        <nav id="match-tab-nav" class="flex -mb-px" aria-label="Tabs">
            <button class="tab-link <?php echo ($active_tab === 'live') ? 'tab-active' : ''; ?> flex-1 text-center" data-tab="live">
                Live (<?php echo count($live_matches); ?>)
            </button>
            <button class="tab-link <?php echo ($active_tab === 'schedule') ? 'tab-active' : ''; ?> flex-1 text-center" data-tab="schedule">
                Scheduled (<?php echo count($scheduled_matches); ?>)
            </button>
            <button class="tab-link <?php echo ($active_tab === 'channels') ? 'tab-active' : ''; ?> flex-1 text-center" data-tab="channels">
                Channels (<?php echo count($stream_channels); ?>)
            </button>
        </nav>
    </div>

    <div id="match-list-panels">
        
        <div id="tab-panel-live" class="tab-panel space-y-4 <?php echo ($active_tab !== 'live') ? 'hidden' : ''; ?>">
            <?php if (!empty($live_matches)): ?>
                <?php foreach ($live_matches as $match): ?>
                    <?php
                        $homeBadge = PLACEHOLDER_IMG;
                        $awayBadge = PLACEHOLDER_IMG;
                        $showBadges = true;

                        if (empty($match['teams']['home']['name']) && empty($match['teams']['away']['name'])) {
                            if (stripos($match['title'], ' vs ') !== false) {
                                $parts = explode(' vs ', $match['title']);
                                $homeName = trim($parts[0]);
                                $awayName = trim($parts[1] ?? 'Team B');
                            } else {
                                $homeName = $match['title'];
                                $awayName = 'Live';
                                $showBadges = false;
                            }
                        } else {
                            $homeName = $match['teams']['home']['name'];
                            $awayName = $match['teams']['away']['name'];
                            $homeBadge = $match['teams']['home']['badge'] ?? PLACEHOLDER_IMG;
                            $awayBadge = $match['teams']['away']['badge'] ?? PLACEHOLDER_IMG;
                        }
                        
                        $dataTitle = htmlspecialchars($homeName . ' vs ' . $awayName);
                        $match_category = $match['category'] ?? $current_category;
                    ?>
                    
                    <a href="/<?php echo htmlspecialchars($match_category); ?>/<?php echo htmlspecialchars($match['id']); ?>/" 
                        class="block bg-gray-700 p-4 rounded-lg shadow-md transition-all hover:bg-gray-600 match-item"
                        data-title="<?php echo $dataTitle; ?>">
                        
                        <div class="grid grid-cols-3 items-center text-center pt-2">
                            <div class="flex flex-col sm:flex-row items-center justify-end gap-3">
                                <span class="text-base sm:text-lg font-semibold text-white text-right"><?php echo htmlspecialchars($homeName); ?></span>
                                <?php if ($showBadges): ?>
                                <img src="<?php echo htmlspecialchars($homeBadge); ?>" alt="Badge" class="team-badge" onerror="this.src='<?php echo PLACEHOLDER_IMG; ?>'">
                                <?php endif; ?>
                            </div>
                            <div class="mx-4 text-center h-12 flex flex-col justify-center"> 
                                <p class="text-xl font-bold text-red-500 animate-pulse">LIVE</p>
                            </div>
                            <div class="flex flex-col-reverse sm:flex-row items-center justify-start gap-3">
                                <?php if ($showBadges): ?>
                                <img src="<?php echo htmlspecialchars($awayBadge); ?>" alt="Badge" class="team-badge" onerror="this.src='<?php echo PLACEHOLDER_IMG; ?>'">
                                <?php endif; ?>
                                <span class="text-base sm:text-lg font-semibold text-white text-left"><?php echo htmlspecialchars($awayName); ?></span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
                <p class="text-gray-500 text-center text-sm py-4 no-search-results hidden">No matching results found.</p>
            <?php else: ?>
                <p class="text-gray-400 text-center">No Live broadcasts at this time.</p>
            <?php endif; ?>
        </div>

        <div id="tab-panel-schedule" class="tab-panel space-y-4 <?php echo ($active_tab !== 'schedule') ? 'hidden' : ''; ?>">
            <?php if (!empty($scheduled_matches)): ?>
                <?php foreach ($scheduled_matches as $match): ?>
                    <?php
                        $homeBadge = PLACEHOLDER_IMG;
                        $awayBadge = PLACEHOLDER_IMG;
                        $showBadges = true;

                        if (empty($match['teams']['home']['name']) && empty($match['teams']['away']['name'])) {
                            if (stripos($match['title'], ' vs ') !== false) {
                                $parts = explode(' vs ', $match['title']);
                                $homeName = trim($parts[0]);
                                $awayName = trim($parts[1] ?? 'Team B');
                            } else {
                                $homeName = $match['title'];
                                $awayName = 'Scheduled';
                                $showBadges = false;
                            }
                        } else {
                            $homeName = $match['teams']['home']['name'];
                            $awayName = $match['teams']['away']['name'];
                            $homeBadge = $match['teams']['home']['badge'] ?? PLACEHOLDER_IMG;
                            $awayBadge = $match['teams']['away']['badge'] ?? PLACEHOLDER_IMG;
                        }
                        
                        $dataTitle = htmlspecialchars($homeName . ' vs ' . $awayName);
                        $matchTime = $match['date'];
                        $match_category = $match['category'] ?? $current_category;
                    ?>
                    
                    <a href="/<?php echo htmlspecialchars($match_category); ?>/<?php echo htmlspecialchars($match['id']); ?>/"
                        class="block bg-gray-700 p-4 rounded-lg shadow-md transition-all hover:bg-gray-600 match-item"
                        data-title="<?php echo $dataTitle; ?>">
                        
                        <div class="grid grid-cols-3 items-center text-center pt-2">
                            <div class="flex flex-col sm:flex-row items-center justify-end gap-3">
                                <span class="text-base sm:text-lg font-semibold text-white text-right"><?php echo htmlspecialchars($homeName); ?></span>
                                <?php if ($showBadges): ?>
                                <img src="<?php echo htmlspecialchars($homeBadge); ?>" alt="Badge" class="team-badge" onerror="this.src='<?php echo PLACEHOLDER_IMG; ?>'">
                                <?php endif; ?>
                            </div>
                            <div class="mx-4 text-center h-12 flex flex-col justify-center"> 
                                <div class="local-time" data-timestamp="<?php echo $matchTime; ?>">
                                    <p class="text-lg font-bold text-gray-300">...</p>
                                    <p class="text-sm text-gray-400">...</p>
                                </div>
                            </div>
                            <div class="flex flex-col-reverse sm:flex-row items-center justify-start gap-3">
                                <?php if ($showBadges): ?>
                                <img src="<?php echo htmlspecialchars($awayBadge); ?>" alt="Badge" class="team-badge" onerror="this.src='<?php echo PLACEHOLDER_IMG; ?>'">
                                <?php endif; ?>
                                <span class="text-base sm:text-lg font-semibold text-white text-left"><?php echo htmlspecialchars($awayName); ?></span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
                <p class="text-gray-500 text-center text-sm py-4 no-search-results hidden">No matching results found.</p>
            <?php else: ?>
                <p class="text-gray-400 text-center">No scheduled matches for this category.</p>
            <?php endif; ?>
        </div>

        <div id="tab-panel-channels" class="tab-panel <?php echo ($active_tab !== 'channels') ? 'hidden' : ''; ?>">
            <?php if (!empty($stream_channels)): ?>
                <div class="flex flex-wrap gap-3">
                    <?php foreach ($stream_channels as $channel): ?>
                        <?php 
                            $dataTitle = htmlspecialchars($channel['title']); 
                            $match_category = $channel['category'] ?? $current_category;
                        ?>
                        
                        <a href="/<?php echo htmlspecialchars($match_category); ?>/<?php echo htmlspecialchars($channel['id']); ?>/" 
                            class="flex items-center gap-2 bg-gray-700 p-3 rounded-lg shadow-md transition-all hover:bg-gray-600 match-item"
                            data-title="<?php echo $dataTitle; ?>">
                            <svg class="w-5 h-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M6 20.25h12m-7.5-3.75h3m-3.75 0 3.75 0M6 20.25v-1.5A2.25 2.25 0 0 1 8.25 15h7.5A2.25 2.25 0 0 1 18 16.5v1.5m-12 0v-1.5a2.25 2.25 0 0 1 2.25-2.25h7.5a2.25 2.25 0 0 1 2.25 2.25v1.5" />
                                <path d="M15 9.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                            </svg>
                            <span class="text-sm font-medium text-white"><?php echo htmlspecialchars($channel['title']); ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
                <p class="text-gray-500 text-center text-sm py-4 no-search-results hidden">No matching results found.</p>
            <?php else: ?>
                <p class="text-gray-400 text-center">No channels found for this category.</p>
            <?php endif; ?>
        </div>
        
    </div>
    
    <div id="seo-description-block" class="mt-8 pt-6 border-t border-gray-700 text-gray-400 text-sm space-y-3">
        <h2 class="text-xl font-semibold text-white">Watch <?php echo $seo_category_name; ?> Live Streams on <?php echo $seo_site_name; ?></h2>
        <p><?php echo $seo_p1; ?></p>
        <p><?php echo $seo_p2; ?></p>
    </div>
</div>