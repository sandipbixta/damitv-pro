<?php
?>

<div id="view-watch">
    <?php if (!$match) : ?>
        <div class="bg-red-900 border border-red-700 text-red-200 px-4 py-3 rounded-lg" role="alert">
            <strong class="font-bold">Oops! An Error Occurred:</strong>
            <span class="block sm:inline">
                This content is currently unavailable. This may be due to a technical issue or a content removal request. Please try again in a few minutes.
            </span>
        </div>
        <a href="/" class="mt-4 inline-block bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
            &larr; Back to Home
        </a>

    <?php else : ?>
        <?php
        $share_url = urlencode(rtrim(BASE_URL, '/') . $_SERVER['REQUEST_URI']);
        $share_title = urlencode($page_title);

        $sources = $match['sources'] ?? [];
        $matchTimestamp = $match['date'] ?? 0;
        $matchCategory = $match['category'] ?? 'football';
        
        $sources_json = json_encode($sources);

        $now = time() * 1000;
        $liveWindowMs = 3 * 60 * 60 * 1000;
        $liveWindowEnd = $now;
        $liveWindowStart = $now - $liveWindowMs;
        $isScheduled = $matchTimestamp > $liveWindowEnd;
        $isLive = ($matchTimestamp > 0 && $matchTimestamp >= $liveWindowStart && $matchTimestamp <= $liveWindowEnd);
        $isFinished = ($matchTimestamp > 0 && $matchTimestamp < $liveWindowStart);
        $isConsideredLive = $isLive || ($matchTimestamp === 0 && count($sources) > 0);
        $current_match_id = $match['id'];

        $other_live_matches = [];
        $matches_data = fetch_api('/matches/' . $matchCategory);
        $all_matches = $matches_data['data'] ?? [];
        foreach ($all_matches as $item) {
            $item_time = $item['date'] ?? 0;
            $item_is_live = ($item_time > 0 && $item_time >= $liveWindowStart && $item_time <= $now);
            $isNotCurrentMatch = ($item['id'] !== $current_match_id);
            if ($item_is_live && $isNotCurrentMatch) {
                $other_live_matches[] = $item;
            }
        }
        usort($other_live_matches, function ($a, $b) {
            $popA = $a['popular'] ?? 0;
            $popB = $b['popular'] ?? 0;
            if ($popA !== $popB) return $popB - $popA;
            return ($b['date'] ?? 0) - ($a['date'] ?? 0);
        });
        $other_live_matches = array_slice($other_live_matches, 0, 5);

        $isMatchWithData = !empty($match['teams']['home']['name']);
        $isMatchFromTitle = (empty($match['teams']['home']['name']) && stripos($match['title'], ' vs ') !== false);
        
        $homeName = 'Team A';
        $awayName = 'Team B';
        $homeBadge = PLACEHOLDER_IMG;
        $awayBadge = PLACEHOLDER_IMG;

        if ($isMatchWithData) {
            $homeName = $match['teams']['home']['name'] ?? 'Team A';
            $awayName = $match['teams']['away']['name'] ?? 'Team B';
            $homeBadge = $match['teams']['home']['badge'] ?? PLACEHOLDER_IMG;
            $awayBadge = $match['teams']['away']['badge'] ?? PLACEHOLDER_IMG;
        } elseif ($isMatchFromTitle) {
            $parts = explode(' vs ', $match['title']);
            $homeName = trim($parts[0]);
            $awayName = trim($parts[1] ?? 'Team B');
        }
        ?>

        <div id="player-logic-container" class="relative mb-4" data-timestamp="<?php echo $matchTimestamp; ?>" data-sources="<?php echo htmlspecialchars($sources_json, ENT_QUOTES, 'UTF-8'); ?>" data-is-live="<?php echo $isConsideredLive ? 'true' : 'false'; ?>" data-is-scheduled="<?php echo $isScheduled ? 'true' : 'false'; ?>" data-is-finished="<?php echo $isFinished ? 'true' : 'false'; ?>">
            <div id="player-container-placeholder" class="bg-black rounded-lg aspect-video w-full overflow-hidden shadow-2xl relative">
                <div class="w-full h-full flex justify-center items-center">
                    <p class="text-gray-500">Loading player...</p>
                </div>
            </div>

            <div id="pre-game-info" class="absolute top-0 left-0 w-full h-full bg-gray-900 bg-opacity-80 backdrop-blur-sm flex flex-col justify-center items-center text-center p-4 rounded-lg cursor-pointer">

                <?php if ($isMatchWithData || $isMatchFromTitle) : ?>
                    <div class="grid grid-cols-3 items-center text-center w-full max-w-lg mb-4">
                        <div class="flex flex-col items-center gap-2">
                            <img src="<?php echo htmlspecialchars($homeBadge); ?>" alt="Badge" class="w-14 h-14 sm:w-20 sm:h-20 object-contain bg-gray-700 rounded-full" onerror="this.src='<?php echo PLACEHOLDER_IMG; ?>'">
                            <span class="text-base sm:text-xl font-semibold text-white"><?php echo htmlspecialchars($homeName); ?></span>
                        </div>
                        <div class="mx-4 text-center">
                            <span class="text-2xl sm:text-5xl font-bold text-gray-300">VS</span>
                        </div>
                        <div class="flex flex-col items-center gap-2">
                            <img src="<?php echo htmlspecialchars($awayBadge); ?>" alt="Badge" class="w-14 h-14 sm:w-20 sm:h-20 object-contain bg-gray-700 rounded-full" onerror="this.src='<?php echo PLACEHOLDER_IMG; ?>'">
                            <span class="text-base sm:text-xl font-semibold text-white"><?php echo htmlspecialchars($awayName); ?></span>
                        </div>
                    </div>
                <?php else : ?>
                    <h2 class="text-xl sm:text-3xl font-bold text-white mb-4"><?php echo htmlspecialchars($match['title']); ?></h2>
                <?php endif; ?>

                <div class="mb-4">
                    <p id="match-schedule-local" class="hidden text-base text-gray-300 mb-2">...</p>
                    <div id="countdown-timer" class="text-3xl font-bold text-white" role="timer">
                        --:--:--:--
                    </div>
                    <div id="live-text" class="hidden text-3xl font-bold text-red-500 animate-pulse" role="status">
                        LIVE NOW
                    </div>
                </div>

                <button id="play-stream-button" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-6 rounded-full text-lg shadow-lg transition-all transform hover:scale-105">
                    Start Watching
                </button>
            </div>

        </div>
        <div class="flex flex-col">

            <div id="match-details-breadcrumb" class="mb-2 text-sm text-gray-400 order-3 sm:order-1">
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-2">
                        <li class="inline-flex items-center">
                            <a href="/" class="inline-flex items-center hover:text-white">Home</a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <span class="mx-1">/</span>
                                <a href="/<?php echo htmlspecialchars($matchCategory); ?>/" class="capitalize hover:text-white"><?php echo htmlspecialchars(str_replace('-', ' ', $matchCategory)); ?></a>
                            </div>
                        </li>
                        <li aria-current="page">
                            <div class="flex items-center">
                                <span class="mx-1">/</span>
                                <span class="text-gray-500 capitalize"><?php echo htmlspecialchars($page_title); ?></span>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>

            <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-4 order-1 sm:order-2">

                <div class="flex-grow min-w-0 order-2 sm:order-1">
                    <h1 class="text-xl sm:text-2xl font-bold text-white mb-1 truncate">
                        <?php echo htmlspecialchars($page_title); ?>
                    </h1>
                    <p id="h1-time-info" class="text-sm text-gray-400">...</p>
                </div>

                <div id="server-select-container" class="flex-shrink-0 order-1 sm:order-2">
                </div>

            </div>
            <div id="share-buttons" class="mb-4 flex flex-wrap items-center gap-3 order-2 sm:order-3">
                <span class="text-sm font-semibold text-gray-400">Share this match:</span>
                <div class="flex flex-wrap gap-2">

                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $share_url; ?>" target="_blank" rel="noopener noreferrer" class="share-button hover:bg-blue-600" title="Share on Facebook">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path fill-rule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.773-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clip-rule="evenodd" />
                        </svg>
                    </a>

                    <a href="https://twitter.com/intent/tweet?url=<?php echo $share_url; ?>&text=<?php echo $share_title; ?>" target="_blank" rel="noopener noreferrer" class="share-button hover:bg-sky-500" title="Share on Twitter">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                        </svg>
                    </a>

                    <a href="https://api.whatsapp.com/send?text=<?php echo $share_title; ?>%20<?php echo $share_url; ?>" target="_blank" rel="noopener noreferrer" class="share-button hover:bg-green-500" title="Share on WhatsApp">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path fill-rule="evenodd" d="M18.403 5.633A8.919 8.919 0 0012.053 3c-4.948 0-8.976 4.027-8.976 8.974 0 1.582.413 3.126 1.198 4.488L3 21.116l4.759-1.249a8.981 8.981 0 004.29 1.093h.004c4.947 0 8.975-4.027 8.975-8.973 0-2.39-.942-4.643-2.618-6.317zM12.053 19.609a7.49 7.49 0 01-3.767-.99l-.268-.16-2.809.737.75-2.738-.178-.282a7.49 7.49 0 01-1.14-3.97h.004c0-4.135 3.355-7.49 7.491-7.49a7.49 7.49 0 015.3 2.196 7.49 7.49 0 012.196 5.3c0 4.135-3.355 7.49-7.49 7.49z" clip-rule="evenodd" />
                            <path d="M9.266 8.311c-.196-.098-.44-.148-.732-.148-.148 0-.296.025-.49.074-.196.049-.368.123-.59.345-.221.222-.44.519-.59.741-.148.222-.222.469-.222.667 0 .197.024.368.074.519.049.148.123.296.221.469.099.173.196.32.296.445.098.123.172.222.221.296.049.074.074.123.074.123.074.124.148.247.247.37.1.124.196.222.27.297.075.074.124.123.148.148.025.024.025.024.025.024a3.1 3.1 0 00.468.345c.148.075.296.124.468.173.173.049.346.074.519.074.148 0 .27-.025.394-.074s.247-.123.345-.221c.099-.099.173-.222.222-.369s.074-.32.074-.469c0-.074-.025-.173-.074-.296-.05-.123-.124-.221-.222-.296-.098-.074-.172-.123-.221-.148-.05-.025-.074-.025-.074-.025a.73.73 0 01-.148-.074c-.05-.025-.074-.05-.074-.074 0-.025.024-.05.074-.074.049-.025.098-.074.148-.123.049-.05.123-.124.172-.173.05-.05.074-.074.074-.074.025-.025.05-.05.074-.074.024-.025.049-.05.074-.074.024-.025.049-.05.074-.074.024-.025.049-.05.074-.074.049-.05.074-.074.098-.123.025-.05.025-.074.025-.123 0-.05-.025-.099-.074-.148a.73.T3 0 00-.148-.123.49.49 0 00-.173-.074c-.05-.025-.098-.025-.148-.025-.05 0-.098 0-.148.025s-.074.025-.074.025zM11.83 13.52c.221 0 .418-.025.59-.074.173-.05.32-.123.444-.221.124-.1.222-.222-.296-.369.074-.148.124-.32.124-.49 0-.197-.05-.368-.148-.519-.098-.148-.221-.27-.368-.368s-.32-.173-.49-.222c-.173-.05-.346-.074-.519-.074-.221 0-.418.025-.59.074-.173.05-.32.123-.444-.221.124-.1-.222-.222-.296.369-.074.148-.124.32-.124-.49 0 .197.05.368.148.519.098.148.221.27.368.368s.32.173.49.222c.173.05.346.074.519.074z" />
                        </svg>
                    </a>

                    <a href="https://t.me/share/url?url=<?php echo $share_url; ?>&text=<?php echo $share_title; ?>" target="_blank" rel="noopener noreferrer" class="share-button hover:bg-sky-600" title="Share on Telegram">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path fill-rule="evenodd" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm4.62 6.764c.264.12.36.43.236.69l-3.32 7.02c-.17.36-.51.54-.86.49l-4.11-.63c-.35-.05-.64-.3-.7-.65L6.2 11.21c-.06-.35.17-.68.52-.74l8.84-1.74c.35-.07.68.16.74.52zm-3.8 6.96l2.96-6.24c.05-.1-.02-.22-.12-.27l-7.85 1.54c-.1.02-.17.1-.19.2l-.04.2 2.1 1.63 3 2.9c.08.08.2.08.28 0z" clip-rule="evenodd" />
                        </svg>
                    </a>

                </div>
            </div>
        </div>
        <div id="match-details-description" class="mt-6 p-4 bg-gray-700 rounded-lg text-gray-300 text-sm space-y-2">
            <p>
                Watch the <strong><?php echo htmlspecialchars($page_title); ?></strong> stream live and for free on LiveSport.

                <?php if ($matchTimestamp > 0) : ?>
                    This <?php echo htmlspecialchars($matchCategory); ?> match is scheduled to start on <strong id="seo-match-time" data-timestamp="<?php echo $matchTimestamp; ?>">...</strong> (your local time).
                <?php else : ?>
                    Enjoy this <strong><?php echo htmlspecialchars($matchCategory); ?></strong> live channel 24/7 on LiveSport.
                <?php endif; ?>
            </p>
            <p>
                Get the best quality stream, multiple servers, and real-time updates for <strong><?php echo htmlspecialchars($page_title); ?></strong> right here. Don't miss any of the action!
            </p>
        </div>

</div>


<?php if (!empty($other_live_matches)) : ?>
    <div id="other-matches" class="mt-8 pt-6 border-t border-gray-700">
        <h3 class="text-xl font-semibold text-white mb-4">Other Live Matches</h3>
        <div class="space-y-3">
            <?php foreach ($other_live_matches as $other_match) : ?>
                <?php
                $title = htmlspecialchars($other_match['title']);
                
                if (!empty($other_match['teams']['home']['name'])) {
                    $title = htmlspecialchars($other_match['teams']['home']['name'] ?? 'Team A') . ' vs ' . htmlspecialchars($other_match['teams']['away']['name'] ?? 'Team B');
                }
                
                $other_match_category = $other_match['category'] ?? 'football';
                ?>
                
                <a href="/<?php echo htmlspecialchars($other_match_category); ?>/<?php echo htmlspecialchars($other_match['id']); ?>/" class="block bg-gray-700 p-4 rounded-lg shadow-md transition-all hover:bg-gray-600 
                               flex justify-between items-center">
                    <span class="text-base font-medium text-white truncate pr-4"><?php echo $title; ?></span>
                    <span class="text-sm font-bold text-red-500 animate-pulse flex-shrink-0">LIVE</span>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>
<?php endif; ?>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const playerLogic = document.getElementById('player-logic-container');
        if (!playerLogic) return;

        const matchTimestamp = parseInt(playerLogic.dataset.timestamp, 10);
        const sources = JSON.parse(playerLogic.dataset.sources);
        const isLive = playerLogic.dataset.isLive === 'true';
        const isScheduled = playerLogic.dataset.isScheduled === 'true';
        const isFinished = playerLogic.dataset.isFinished === 'true';

        const placeholder = document.getElementById('player-container-placeholder');
        const preGameInfo = document.getElementById('pre-game-info');
        const scheduleEl = document.getElementById('match-schedule-local');
        const countdownEl = document.getElementById('countdown-timer');
        const liveTextEl = document.getElementById('live-text');
        const playButton = document.getElementById('play-stream-button');
        const serverContainer = document.getElementById('server-select-container');
        const seoTimeEl = document.getElementById('seo-match-time');
        const h1TimeInfoEl = document.getElementById('h1-time-info');

        let countdownInterval = null;
        let isPlayerLoaded = false;
        let currentIframe = null;

        function loadPlayer() {
            if (isPlayerLoaded || !sources.length) {
                if (!sources.length) {
                    placeholder.innerHTML = `<div class="w-full h-full flex justify-center items-center text-red-500">Stream not available.</div>`;
                }
                return;
            }
            isPlayerLoaded = true;

            if (preGameInfo) preGameInfo.classList.add('hidden');
            if (countdownInterval) clearInterval(countdownInterval);

            const iframe = document.createElement('iframe');
            iframe.id = 'stream-iframe';
            iframe.src = sources[0].embedUrl;
            iframe.setAttribute('allow', 'autoplay; encrypted-media; fullscreen');
            iframe.setAttribute('allowfullscreen', 'true');
            iframe.className = 'w-full h-full absolute top-0 left-0 border-none';
            placeholder.innerHTML = '';
            placeholder.appendChild(iframe);
            currentIframe = iframe;

            if (sources.length > 1) {
                let selectHTML = '<label for="server-select" class="sr-only">Select Server:</label>';
                selectHTML += '<select id="server-select" class="dark-select w-full sm:w-auto rounded-lg border border-gray-700 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">';
                
                sources.forEach((source, index) => {
                    const hdBadge = source.hd ? '(HD)' : '';
                    const lang = source.language || 'N/A';
                    const srcName = source.source ? `- ${source.source}` : '';
                    const streamNo = source.streamNo || (index + 1);
                    const label = `Server ${streamNo} (${lang}) ${hdBadge} ${srcName}`;
                    selectHTML += `<option value="${source.embedUrl}">${label}</option>`;
                });
                
                selectHTML += '</select>';
                serverContainer.innerHTML = selectHTML;

                document.getElementById('server-select').addEventListener('change', (e) => {
                    if (currentIframe) {
                        currentIframe.src = e.target.value;
                    }
                });
            }
        }

        function updateCountdown() {
            const now = new Date().getTime();
            const diff = matchTimestamp - now;
            const liveWindowMs = 3 * 60 * 60 * 1000;

            if (diff <= 0 && diff > -liveWindowMs) {
                clearInterval(countdownInterval);
                countdownEl.classList.add('hidden');
                liveTextEl.classList.remove('hidden');
                const newText = 'Currently Live';
                scheduleEl.textContent = newText;
                if (seoTimeEl) seoTimeEl.textContent = 'which is currently live';
                if (h1TimeInfoEl) h1TimeInfoEl.textContent = newText;
                return;
                
            } else if (diff <= -liveWindowMs) {
                clearInterval(countdownInterval);
                countdownEl.classList.add('hidden');
                liveTextEl.classList.add('hidden');

                const finishedText = 'Match Finished';
                if (seoTimeEl) seoTimeEl.textContent = 'which has already finished';
                scheduleEl.textContent = finishedText;
                liveTextEl.textContent = finishedText;
                liveTextEl.classList.remove('hidden', 'text-red-500', 'animate-pulse');
                liveTextEl.classList.add('text-gray-400', 'text-2xl');
                return;
            }

            const d = Math.floor(diff / (1000 * 60 * 60 * 24));
            const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            const s = Math.floor((diff % (1000 * 60)) / 1000);

            let countdownText = '';
            if (d > 0) countdownText += `${d}d `;
            countdownText += `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
            countdownEl.textContent = countdownText;
        }

        function displayLocalSchedule() {
            let scheduleText = 'Schedule Error';
            let seoText = 'at the scheduled time';
            let h1Text = 'Schedule TBD';

            if (!matchTimestamp || matchTimestamp === 0) {
                scheduleText = 'Live Channel';
                seoText = 'Enjoy this live channel 24/7.';
                h1Text = 'Live Channel 24/7';
                if (seoTimeEl) seoTimeEl.parentElement.textContent = seoText;
            } else {
                try {
                    const date = new Date(matchTimestamp);
                    const timeZoneName = date.toLocaleTimeString('en-us', {
                        timeZoneName: 'short'
                    }).split(' ')[2];
                    const options = {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                        hour12: false,
                        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone
                    };
                    const fullDateTime = date.toLocaleString('en-US', options);
                    
                    scheduleText = `${fullDateTime} (${timeZoneName})`;
                    seoText = scheduleText;
                    h1Text = scheduleText;

                    if (seoTimeEl) seoTimeEl.textContent = seoText;

                } catch (e) {
                }
            }
            
            scheduleEl.textContent = scheduleText;
            if (h1TimeInfoEl) h1TimeInfoEl.textContent = h1Text;
        }

        preGameInfo.addEventListener('click', (e) => {
            if (e.target === preGameInfo || e.target.closest('#play-stream-button')) {
                loadPlayer();
            }
        });

        if (isLive) {
            displayLocalSchedule();
            countdownEl.classList.add('hidden');
            liveTextEl.classList.remove('hidden');
            
            const liveText = (matchTimestamp === 0) ? 'Live Channel 24/7' : 'Currently Live';
            if (seoTimeEl) seoTimeEl.textContent = (matchTimestamp === 0) ? 'Enjoy this live channel 24/7' : 'which is currently live';
            if (h1TimeInfoEl) h1TimeInfoEl.textContent = liveText;
            scheduleEl.textContent = liveText;

        } else if (isScheduled) {
            liveTextEl.classList.add('hidden');
            countdownEl.classList.remove('hidden');
            displayLocalSchedule();
            updateCountdown();
            countdownInterval = setInterval(updateCountdown, 1000);
            
        } else if (isFinished) {
            liveTextEl.classList.add('hidden');
            countdownEl.classList.add('hidden');
            displayLocalSchedule();

            const finishedText = 'Match Finished';
            if (seoTimeEl) seoTimeEl.textContent = 'which has already finished';
            scheduleEl.textContent = finishedText;
            liveTextEl.textContent = finishedText;
            liveTextEl.classList.remove('hidden', 'text-red-500', 'animate-pulse');
            liveTextEl.classList.add('text-gray-400', 'text-2xl');

        } else {
            displayLocalSchedule();
            countdownEl.classList.add('hidden');
            liveTextEl.classList.add('hidden');
        }
    });
</script>