</main>
<footer class="bg-gray-900 mt-10 border-t border-gray-700">
    <div class="container max-w-6xl mx-auto p-6 md:p-10 text-gray-400">

        <?php
        $score_leagues_list = [];
        if (function_exists('fetch_api')) {
            $leagues_result = fetch_api('/results/leagues');
            $score_leagues_list = $leagues_result['data'] ?? [];
        }

        if (!empty($score_leagues_list)) :
        ?>
            <div class="mb-8">
                <h3 class="text-lg font-semibold text-white mb-4">Scores</h3>
                <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                    <?php foreach ($score_leagues_list as $league) : ?>
                        <a href="/scores/<?php echo htmlspecialchars($league['id']); ?>/" class="text-sm hover:text-white hover:underline transition-colors">
                            <?php echo htmlspecialchars($league['name']); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif;

        if (!empty($categories)) :
        ?>
            <div class="mb-8">
                <h3 class="text-lg font-semibold text-white mb-4">Categories</h3>
                <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                    <?php foreach ($categories as $category) : ?>
                        <a href="/<?php echo htmlspecialchars($category['id']); ?>/" class="text-sm hover:text-white hover:underline transition-colors">
                            <?php echo htmlspecialchars($category['name']); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="mb-8">
            <h3 class="text-lg font-semibold text-white mb-4">Disclaimer</h3>
            <div class="text-xs space-y-2">
                <p>
                    <?php echo SITE_NAME; ?> does not host any of the materials on our own servers. All material, including images, video streams, schedules, and any related content on this site comes from multiple 3rd-party sources.
                </p>
                <p>
                    If you are the owner of any copyrighted material and wish for it to be removed, please contact us via email at:
                    <strong><?php echo SITE_EMAIL; ?></strong>
                </p>
            </div>
        </div>

        <div class="mt-8 pt-6 border-t border-gray-700 text-center text-sm">
            <p>
                Copyright &copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All Rights Reserved.
            </p>
        </div>

    </div>
</footer>

<?php
$TextInstall = TEXT_INSTALL;
if (!empty($TextInstall)) : ?>
    <button id="installButton" style="display: none;" class="fixed bottom-6 left-6 z-40 flex items-center gap-2 px-4 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow-lg transition-all hover:bg-blue-700 hover:scale-105">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
        </svg>
        <span><?php echo $TextInstall ?></span>
    </button>
<?php endif; ?>
<script>
    document.addEventListener('DOMContentLoaded', () => {

        const categorySelect = document.getElementById('category-select');
        if (categorySelect) {
            categorySelect.addEventListener('change', (e) => {
                const baseUrl = window.location.origin;
                window.location.href = baseUrl + '/' + e.target.value + '/';
            });
        }

        const leagueSelect = document.getElementById('league-select');
        if (leagueSelect) {
            leagueSelect.addEventListener('change', (e) => {
                const baseUrl = window.location.origin;
                if (e.target.value === "") {
                    window.location.href = baseUrl + '/scores/';
                } else {
                    window.location.href = baseUrl + '/scores/' + e.target.value + '/';
                }
            });
        }

        document.querySelectorAll('[data-timestamp]').forEach(el => {
            if (el.id === 'player-logic-container' || el.closest('#player-logic-container')) {
                return;
            }

            try {
                const timestamp = parseInt(el.dataset.timestamp, 10);
                if (isNaN(timestamp) || timestamp === 0) {
                    el.innerHTML = 'Schedule TBD';
                    return;
                }

                const date = new Date(timestamp);
                const now = new Date();
                const isToday = date.toDateString() === now.toDateString();

                const timeZoneShort = date.toLocaleTimeString('en-us', {
                    timeZoneName: 'short'
                }).split(' ')[2];

                if (el.classList.contains('local-time')) {
                    let timeString = date.toLocaleTimeString('en-US', {
                        hour: '2-digit',
                        minute: '2-digit',
                        hour12: false
                    });
                    let dateString = '';
                    if (!isToday) {
                        dateString = date.toLocaleDateString('en-US', {
                            day: '2-digit',
                            month: 'short'
                        }) + ' ';
                    }
                    el.innerHTML = `<p class="text-lg font-bold text-gray-300">${dateString}${timeString}</p><p class="text-sm text-gray-400">${timeZoneShort}</p>`;

                } else if (el.classList.contains('local-time-full')) {
                    const fullDateTime = date.toLocaleString('en-US', {
                        dateStyle: 'medium',
                        timeStyle: 'short',
                        hour12: false
                    });
                    el.innerHTML = `${fullDateTime} (${timeZoneShort})`;

                } else if (el.classList.contains('local-time-date')) {
                    let timeString = date.toLocaleTimeString('en-US', {
                        hour: '2-digit',
                        minute: '2-digit',
                        hour12: false
                    });
                    let dateString = date.toLocaleDateString('en-US', {
                        day: '2-digit',
                        month: 'short'
                    });
                    el.innerHTML = `${dateString}, ${timeString} (${timeZoneShort})`;
                }
            } catch (e) {
                el.innerHTML = "Schedule Error";
                console.error("Failed to format date", e);
            }
        });

        const toggleBtn = document.getElementById('menu-toggle');
        const menu = document.getElementById('main-menu');

        if (toggleBtn && menu) {
            toggleBtn.addEventListener('click', () => {
                menu.classList.toggle('hidden');
                const isExpanded = menu.classList.contains('hidden') ? 'false' : 'true';
                toggleBtn.setAttribute('aria-expanded', isExpanded);
            });
        }

        const tabContainer = document.getElementById('match-tab-nav');
        const panelContainer = document.getElementById('match-list-panels');

        if (tabContainer && panelContainer) {

            const tabLinks = tabContainer.querySelectorAll('.tab-link');
            const tabPanels = panelContainer.querySelectorAll('.tab-panel');

            tabContainer.addEventListener('click', (e) => {
                const clickedTab = e.target.closest('.tab-link');
                if (!clickedTab) return;

                e.preventDefault();

                tabLinks.forEach(link => link.classList.remove('tab-active'));
                clickedTab.classList.add('tab-active');

                tabPanels.forEach(panel => panel.classList.add('hidden'));

                const tabId = clickedTab.dataset.tab;
                const activePanel = document.getElementById(`tab-panel-${tabId}`);
                if (activePanel) {
                    activePanel.classList.remove('hidden');
                }

                const searchInputOnPage = document.getElementById('match-search-input');
                if (searchInputOnPage) {
                    searchInputOnPage.value = '';
                    if (typeof filterActivePanel === 'function') {
                        filterActivePanel(activePanel, '');
                    }
                }
            });
        }

        const searchInput = document.getElementById('match-search-input');
        if (searchInput && panelContainer) {

            searchInput.addEventListener('input', (e) => {
                const query = e.target.value.toLowerCase();
                const activePanel = panelContainer.querySelector('.tab-panel:not(.hidden)');
                if (activePanel) {
                    filterActivePanel(activePanel, query);
                }
            });

            function filterActivePanel(panel, query) {
                let itemsFound = 0;
                const items = panel.querySelectorAll('.match-item');
                const noResultsMsg = panel.querySelector('.no-search-results');

                items.forEach(item => {
                    const title = item.dataset.title.toLowerCase();
                    if (title.includes(query)) {
                        item.style.display = '';
                        itemsFound++;
                    } else {
                        item.style.display = 'none';
                    }
                });

                if (noResultsMsg) {
                    if (itemsFound === 0 && items.length > 0) {
                        noResultsMsg.classList.remove('hidden');
                    } else {
                        noResultsMsg.classList.add('hidden');
                    }
                }
            }
        }

        let deferredPrompt;
        const installButton = document.getElementById('installButton');

        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            if (installButton) {
                installButton.style.display = 'flex';
            }
        });

        if (installButton) {
            installButton.addEventListener('click', () => {
                if (!deferredPrompt) {
                    return;
                }
                installButton.style.display = 'none';
                deferredPrompt.prompt();
                deferredPrompt.userChoice.then((result) => {
                    if (result.outcome === 'accepted') {
                        console.log('User accepted the install prompt');
                    } else {
                        console.log('User dismissed the install prompt');
                    }
                    deferredPrompt = null;
                });
            });
        }

    });
</script>
</body>

</html>