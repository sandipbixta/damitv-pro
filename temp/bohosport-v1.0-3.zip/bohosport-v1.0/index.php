<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/loader.php';

$request_uri = trim($_SERVER['REQUEST_URI'], '/');

$request_path = strtok($request_uri, '?');
$uri_parts = explode('/', $request_path);

$page = $uri_parts[0] ?? 'home';

$page_title = 'Home';
$current_category = 'football';
$template_file = '';
$og_image = PLACEHOLDER_IMG;

$categories_data = fetch_api('/sports');
$categories = $categories_data['data'] ?? [];

if ($page === 'home' || empty($page)) {
    $page_title = 'Home';
    $current_category = 'football';
    $template_file = 'templates/' . SITE_TEMPLATE . '/home.php';

} elseif ($page === 'scores') {
    $seo_p1 = '';
    $seo_p2 = '';

    $leagues_result = fetch_api('/results/leagues');
    $all_leagues = $leagues_result['data'] ?? [];
    usort($all_leagues, function($a, $b) { return strcmp($a['name'], $b['name']); });

    $live_matches = [];
    $finished_matches = [];
    $tables_data = [];
    $last_updated_timestamp_ms = 0;
    $current_league_name = "Football Scores";
    $is_filtered_page = false;

    if (isset($uri_parts[1]) && !empty($uri_parts[1])) {
        $is_filtered_page = true;
        $current_league_slug = filter_var($uri_parts[1], FILTER_UNSAFE_RAW);

        $scores_result = fetch_api('/results/scores/' . $current_league_slug);
        $live_matches = $scores_result['data']['live'] ?? [];
        $finished_matches = $scores_result['data']['finished'] ?? [];
        $last_updated_iso = $scores_result['data']['last_updated'] ?? null;
        if ($last_updated_iso) {
            try { $last_updated_timestamp_ms = strtotime($last_updated_iso) * 1000; } catch (Exception $e) {}
        }
        usort($finished_matches, function($a, $b) { return strtotime($b['utcDate']) - strtotime($a['utcDate']); });

        $tables_result = fetch_api('/results/tables/' . $current_league_slug);
        $tables_data = $tables_result['data']['standings'][0]['table'] ?? [];

        foreach ($all_leagues as $league) {
            if ($league['id'] === $current_league_slug) {
                $current_league_name = $league['name'];
                $page_title = $current_league_name . ' Scores & Tables';
                break;
            }
        }
    } else {
        $page_title = 'Live Football Scores & Tables';
    }

    $seo_site_name = SITE_NAME;
    $seo_title = $page_title;
    $leagues_text = implode(', ', array_slice(array_column($all_leagues, 'name'), 0, 5));
    if (empty($leagues_text)) $leagues_text = "top leagues";

    $seo_p1 = "Get the latest football scores on {$seo_site_name}. We provide real-time updates, live scores, match results, and league tables from " . htmlspecialchars($leagues_text) . " and more.";

    if ($is_filtered_page) {
         $seo_p1 = "Get the latest scores, results, and tables for " . htmlspecialchars($current_league_name) . " on {$seo_site_name}. We provide real-time updates for live matches and complete results.";
         $live_count = count($live_matches);
         $tables_count = count($tables_data);
         if ($live_count > 0) {
            $first_live_match = reset($live_matches);
            $home = $first_live_match['homeTeam']['name'];
            $away = $first_live_match['awayTeam']['name'];
            $seo_p2 = "There are currently $live_count live matches, including " . htmlspecialchars($home) . " vs " . htmlspecialchars($away) . ".";
         } elseif ($tables_count > 0) {
            $first_team = reset($tables_data);
            $seo_p2 = "There are no live matches, but you can check the latest table standings. " . htmlspecialchars($first_team['team']['name']) . " is currently in position " . $first_team['position'] . ".";
         } else {
            $seo_p2 = "There is currently no live match or table data available for " . htmlspecialchars($current_league_name) . ". Please check back soon.";
         }
    } else {
        $seo_p2 = "Select a league from the dropdown menu to see all the latest information, including live scores, finished match results, and up-to-date league standings.";
    }

    $template_file = 'templates/' . SITE_TEMPLATE . '/scores.php';

} elseif (isset($uri_parts[0]) && !empty($uri_parts[0])) {
    $category_slug = filter_var($uri_parts[0], FILTER_UNSAFE_RAW);

    if (isset($uri_parts[1]) && !empty($uri_parts[1])) {
        $match_id_raw = filter_var($uri_parts[1], FILTER_UNSAFE_RAW);
        $_GET['category'] = $category_slug;
        $detail_data = fetch_api('/matches/' . $match_id_raw . '/detail');
        $match = $detail_data['data'] ?? null;

        if ($match) {
            if (empty($match['teams']['home']['name']) && empty($match['teams']['away']['name'])) {
                $page_title = $match['title'];
            } else {
                $page_title = ($match['teams']['home']['name'] ?? 'Team A') . ' vs ' . ($match['teams']['away']['name'] ?? 'Team B');
            }
            $current_category = $match['category'] ?? $category_slug;
            if (!empty($match['poster'])) {
                $og_image = $match['poster'];
            } elseif (!empty($match['teams']['home']['badge'])) {

                $og_image = $match['teams']['home']['badge'];
            }
        } else { $page_title = 'Error'; }
        $template_file = 'templates/' . SITE_TEMPLATE . '/player.php';

    } else {
        $isValidCategory = false;
        foreach ($categories as $cat) {
            if ($cat['id'] === $category_slug) {
                $isValidCategory = true;
                $page_title = $cat['name'];
                break;
            }
        }
        if ($isValidCategory) {
            $template_file = 'templates/' . SITE_TEMPLATE . '/home.php';
            $current_category = $category_slug;
        } else {
            $template_file = 'templates/' . SITE_TEMPLATE . '/404.php';
            $page_title = '404 Not Found';
            http_response_code(404);
        }
    }
} else {
    $template_file = 'templates/' . SITE_TEMPLATE . '/404.php';
    $page_title = '404 Page Not Found';
    http_response_code(404);
}

include 'templates/' . SITE_TEMPLATE . '/header.php';

if (file_exists($template_file)) {
    include $template_file;
} else {
    echo '<p class="text-red-500">Error: no template file found.</p>';
}

include 'templates/' . SITE_TEMPLATE . '/footer.php';
?>