<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/loader.php';

$category_slug = $_GET['category'] ?? null;

if (!$category_slug) {
    header("HTTP/1.0 404 Not Found");
    die("No category specified.");
}

$matches_data = fetch_api('/matches/' . $category_slug);
$matches = $matches_data['data'] ?? [];

$base_url = rtrim(BASE_URL, '/');
$today = date('Y-m-d');
$now = time() * 1000;
$liveWindowStart = $now - (3 * 60 * 60 * 1000);

header('Content-Type: application/xml; charset=utf-8');

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

if (!empty($matches)) {
    foreach ($matches as $match) {
        
        $match_id = htmlspecialchars($match['id']);
        $match_time = $match['date'] ?? 0;
        
        $cat_slug_for_url = htmlspecialchars($match['category'] ?? $category_slug);
        $url = $base_url . "/" . $cat_slug_for_url . "/" . $match_id . "/";
        
        
        if ($match_time === 0) {
            $lastmod = $today;
            $changefreq = 'weekly';
            $priority = '0.7';
            
        } elseif ($match_time > $now) {
            $lastmod = date('Y-m-d', $match_time / 1000);
            $changefreq = 'daily';
            $priority = '0.8';
            
        } elseif ($match_time >= $liveWindowStart && $match_time <= $now) {
            $lastmod = $today;
            $changefreq = 'daily';
            $priority = '0.9';
            
        } else {
            $lastmod = date('Y-m-d', $match_time / 1000);
            $changefreq = 'never';
            $priority = '0.3';
        }
        
        echo "  <url>\n";
        echo "    <loc>" . $url . "</loc>\n";
        echo "    <lastmod>" . $lastmod . "</lastmod>\n";
        echo "    <changefreq>" . $changefreq . "</changefreq>\n";
        echo "    <priority>" . $priority . "</priority>\n";
        echo "  </url>\n";
    }
}

echo '</urlset>';
?>