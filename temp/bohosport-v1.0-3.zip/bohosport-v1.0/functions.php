<?php

function format_match_time($timestamp) {
    if (empty($timestamp) || $timestamp == 0) return '';
    $date = new DateTime('@' . ($timestamp / 1000));
    $now = new DateTime();
    if ($date->format('Y-m-d') == $now->format('Y-m-d')) {
        return $date->format('H:i');
    } else {
        return $date->format('d M, H:i');
    }
}
function format_full_date_time($timestamp) {
    if (empty($timestamp) || $timestamp == 0) return 'Live Now';
    $date = new DateTime('@' . ($timestamp / 1000));
    if (class_exists('IntlDateFormatter')) {
        $formatter = new IntlDateFormatter('id_ID', IntlDateFormatter::LONG, IntlDateFormatter::SHORT, 'Asia/Jakarta', IntlDateFormatter::GREGORIAN, 'd MMMM yyyy, HH:mm');
        return $formatter->format($date);
    } else {
        return $date->format('d M Y, H:i');
    }
}
function format_seo_date($timestamp) {
    if (empty($timestamp) || $timestamp == 0) return 'Live Channel 24/7';
    $date = new DateTime('@' . ($timestamp / 1000));
    $date->setTimezone(new DateTimeZone('UTC'));
    return $date->format('l, F j, Y \a\t H:i \U\T\C');
}
function format_iso_date($timestamp) {
    if (empty($timestamp) || $timestamp == 0) return null;
    $date = new DateTime('@' . ($timestamp / 1000));
    $date->setTimezone(new DateTimeZone('UTC'));
    return $date->format('c');
}
function slugify($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    if (empty($text)) return 'n-a';
    return $text;
}

?>