<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: text/plain; charset=utf-8');

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/loader.php';

if (!isset($_GET['token']) || $_GET['token'] !== PING_TOKEN) {
    http_response_code(403);
    exit('❌ ERROR: Invalid or missing token.');
}

$stateFile   = __DIR__ . '/ping-state.json';
$baseUrl     = rtrim(BASE_URL, '/');
$keyFilePath = $_SERVER['DOCUMENT_ROOT'];

$stateData = [];
if (!file_exists($stateFile)) {
    $key = bin2hex(random_bytes(16));
    $stateData = [
        'indexnow_key'        => $key,
        'key_created_at'      => date('c'),
        'next_category_index' => 0
    ];
    file_put_contents($stateFile, json_encode($stateData, JSON_PRETTY_PRINT));
    echo "✅ Successfully created ping-state.json\n";
} else {
    $stateData = json_decode(file_get_contents($stateFile), true);
    if (!is_array($stateData) || empty($stateData['indexnow_key'])) {
        die("❌ ERROR: ping-state.json is invalid or missing key.\n");
    }
}

$key         = $stateData['indexnow_key'];
$nextIndex   = $stateData['next_category_index'] ?? 0;

$keyTxtPath = $keyFilePath . '/' . $key . '.txt';
if (!file_exists($keyTxtPath)) {
    file_put_contents($keyTxtPath, $key);
    @chmod($keyTxtPath, 0644);
    echo "✅ Successfully created verification file $key.txt\n";
}

$categories_data = fetch_api('/sports');
$categories = $categories_data['data'] ?? [];

if (empty($categories)) {
    die("❌ ERROR: Failed to fetch category list from API.\n");
}

$totalCategories = count($categories);
if ($nextIndex >= $totalCategories) {
    $nextIndex = 0;
}

$categoryToPing = $categories[$nextIndex];
$categorySlug = $categoryToPing['id'];
echo "⚙️ Processing Category: " . $categoryToPing['name'] . " (Index $nextIndex / $totalCategories)\n";

$matches_data = fetch_api('/matches/' . $categorySlug);
$matches = $matches_data['data'] ?? [];

if (empty($matches)) {
    echo "ℹ️ No matches found for category '$categorySlug'. Moving to next index.\n";

    $stateData['next_category_index'] = ($nextIndex + 1 >= $totalCategories) ? 0 : $nextIndex + 1;
    file_put_contents($stateFile, json_encode($stateData, JSON_PRETTY_PRINT));
    exit;
}

$urlList = [];
foreach ($matches as $match) {
    $cat_slug_for_url = htmlspecialchars($match['category'] ?? $categorySlug);
    $match_id = htmlspecialchars($match['id']);
    $urlList[] = $baseUrl . "/" . $cat_slug_for_url . "/" . $match_id . "/";
}

echo "🔎 Found " . count($urlList) . " URLs to ping.\n";

$payload = json_encode([
    'host'    => parse_url($baseUrl, PHP_URL_HOST),
    'key'     => $key,
    'urlList' => $urlList
]);

$ch = curl_init('https://api.indexnow.org/indexnow');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json; charset=utf-8'],
    CURLOPT_POSTFIELDS     => $payload,
    CURLOPT_TIMEOUT        => 10
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200 || $httpCode === 202) {
    echo "✅ SUCCESS: HTTP $httpCode. IndexNow accepted the URLs.\n";

    $stateData['next_category_index'] = ($nextIndex + 1 >= $totalCategories) ? 0 : $nextIndex + 1;
    file_put_contents($stateFile, json_encode($stateData, JSON_PRETTY_PRINT));
    echo "💾 Log updated. Next cron run will process index " . $stateData['next_category_index'] . ".\n";

} else {
    echo "❌ FAILED: HTTP $httpCode. Server response: $response\n";
    echo "ℹ️ Index not updated, will retry on the next cycle.\n";
}

?>