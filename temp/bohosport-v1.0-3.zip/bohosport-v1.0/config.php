<?php

// 🔧 Site basic configuration
define('SITE_NAME', 'BOHOSport'); // Website name displayed in titles or headers
define('BASE_URL', 'https://YOUR_DOMAIN.COM'); // Main domain URL (update with your actual domain)
define('SITE_EMAIL', 'EMAIL@YOUR_DOMAIN.COM'); // Admin or support email address
define('TEXT_INSTALL', 'Install App!'); // Text for the install or download button
define('SITE_TEMPLATE', 'dark'); // Template folder name inside /templates/ (e.g., /templates/dark/)

// 🔐 Security and license settings
define('MY_LICENSE_KEY', 'YOUR_LICENSE_KEY'); // License key from your Bohodev member area
define('PING_TOKEN', 'YOUR_PING_TOKEN'); // Custom token you create manually for ping indexer

// 🌐 API and assets
define('API_URL', 'https://streamapi.cc/sport/'); // Base API endpoint for fetching sports data
define('PLACEHOLDER_IMG', 'https://placehold.co/40x40/374151/E5E7EB?text=N/A'); // Default placeholder when an image is missing

// ⚙️ System configuration
define('CACHE_DIR', __DIR__ . '/cache'); // Cache directory used for storing temporary API data
date_default_timezone_set('Asia/Jakarta'); // Server timezone setting (adjust if needed)
