<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/loader.php';

$categories_data = fetch_api('/sports');
$categories = $categories_data['data'] ?? [];

$leagues_result = fetch_api('/results/leagues');
$score_leagues = $leagues_result['data'] ?? [];

$base_url = rtrim(BASE_URL, '/');
$today = date('Y-m-d');

header('Content-Type: application/xml; charset=utf-8');

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

echo "  <url>\n";
echo "    <loc>" . $base_url . "/</loc>\n";
echo "    <lastmod>" . $today . "</lastmod>\n";
echo "    <changefreq>daily</changefreq>\n";
echo "    <priority>1.0</priority>\n";
echo "  </url>\n";

echo "  <url>\n";
echo "    <loc>" . $base_url . "/scores/</loc>\n";
echo "    <lastmod>" . $today . "</lastmod>\n";
echo "    <changefreq>daily</changefreq>\n";
echo "    <priority>0.9</priority>\n";
echo "  </url>\n";

if (!empty($categories)) {
    foreach ($categories as $category) {
        $cat_slug = htmlspecialchars($category['id']);
        echo "  <url>\n";
        echo "    <loc>" . $base_url . "/" . $cat_slug . "/</loc>\n";
        echo "    <lastmod>" . $today . "</lastmod>\n";
        echo "    <changefreq>daily</changefreq>\n";
        echo "    <priority>0.9</priority>\n";
        echo "  </url>\n";
    }
}

if (!empty($score_leagues)) {
    foreach ($score_leagues as $league) {
        if (empty($league['id'])) continue;
        
        $league_id = htmlspecialchars($league['id']);
        echo "  <url>\n";
        echo "    <loc>" . $base_url . "/scores/" . $league_id . "/</loc>\n";
        echo "    <lastmod>" . $today . "</lastmod>\n";
        echo "    <changefreq>daily</changefreq>\n";
        echo "    <priority>0.8</priority>\n";
        echo "  </url>\n";
    }
}

echo '</urlset>';
?>